M1PC_RevA Gerber files

M1PC_RevA.drl - Excellon drill file
M1PC_RevA.gto - top silkscreen
M1PC_RevA.gts - top solder mask
M1PC_RevA.gtl - top copper
M1PC_RevA.g2 - inner layer 1
M1PC_RevA.g3 - inner layer 2
M1PC_RevA.gbl - bottom copper
M1PC_RevA.gbs - bottom solder mask
M1PC_RevA.gm1 - board outline

