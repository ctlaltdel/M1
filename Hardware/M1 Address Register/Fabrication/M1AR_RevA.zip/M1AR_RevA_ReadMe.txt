M1AR_RevA Gerber files

M1AR_RevA.drl - Excellon drill file
M1AR_RevA.gto - top silkscreen
M1AR_RevA.gts - top solder mask
M1AR_RevA.gtl - top copper
M1AR_RevA.g2 - inner layer 1
M1AR_RevA.g3 - inner layer 2
M1AR_RevA.gbl - bottom copper
M1AR_RevA.gbs - bottom solder mask
M1AR_RevA.gm1 - board outline

