M1CC_RevA Gerber files

M1CC_RevA.drl - Excellon drill file
M1CC_RevA.gtp - top paste mask
M1CC_RevA.gto - top silkscreen
M1CC_RevA.gts - top solder mask
M1CC_RevA.gtl - top copper
M1CC_RevA.g2 - inner layer 1
M1CC_RevA.g3 - inner layer 2
M1CC_RevA.gbl - bottom copper
M1CC_RevA.gbs - bottom solder mask
M1CC_RevA.gm1 - board outline

