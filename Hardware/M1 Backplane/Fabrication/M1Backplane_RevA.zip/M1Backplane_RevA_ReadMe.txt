M1Backplane_RevA Gerber files

M1Backplane_RevA.drl - Excellon drill file
M1Backplane_RevA.gto - top silkscreen
M1Backplane_RevA.gts - top solder mask
M1Backplane_RevA.gtl - top copper
M1Backplane_RevA.g2 - inner layer 1
M1Backplane_RevA.g3 - inner layer 2
M1Backplane_RevA.gbl - bottom copper
M1Backplane_RevA.gbs - bottom solder mask
M1Backplane_RevA.gm1 - board outline

