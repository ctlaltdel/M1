M1TR_RevA Gerber files

M1TR_RevA.drl - Excellon drill file
M1TR_RevA.gto - top silkscreen
M1TR_RevA.gts - top solder mask
M1TR_RevA.gtl - top copper
M1TR_RevA.g2 - inner layer 1
M1TR_RevA.g3 - inner layer 2
M1TR_RevA.gbl - bottom copper
M1TR_RevA.gbs - bottom solder mask
M1TR_RevA.gm1 - board outline

